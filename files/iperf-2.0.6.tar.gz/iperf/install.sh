build_iperf() {
    #set -e
    ./configure
    make && make install 
}

build_iperf
